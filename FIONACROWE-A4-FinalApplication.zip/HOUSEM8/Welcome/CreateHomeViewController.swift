//
//  CreateHomeViewController.swift
//  HOUSEM8
//
//  Created by Fiona Crowe on 18/6/21.
//

import UIKit

class CreateHomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    
    
    
    
    let SECTION_INVITE = 0
    
    let CELL_INVITE = "inviteCell"

    @IBOutlet weak var houseNameField: UITextField!
    @IBOutlet weak var invitationTable: UITableView!
    
    var user: User?
    var databaseController: DatabaseProtocol?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        databaseController = appDelegate?.databaseController

        // Do any additional setup after loading the view.
    }
    
    @IBAction func createHome(_ sender: Any) {
        if let homeName = houseNameField.text {
            let homeAddress = "1 hardcoded avenue"
            if let newHome = databaseController?.addHome(homeAddress: homeAddress, homeName: homeName) {
                self.user?.addHome(home: newHome)
                
                guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                    let sceneDelegate = windowScene.delegate as? SceneDelegate
                  else {
                    return
                  }
                
                
                sceneDelegate.goToHome()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.user?.invitations.count) ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Initialise mealCell
        let invitationCell = tableView.dequeueReusableCell(withIdentifier: CELL_INVITE, for: indexPath)
        
        // Set label appropriately
        invitationCell.textLabel?.text = "Tap to enter email"
    
        return invitationCell
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
